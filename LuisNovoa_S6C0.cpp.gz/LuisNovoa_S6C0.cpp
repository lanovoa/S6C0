#include <iostream>
#include <cstdlib>
#include <math.h>

using std::cout;
using std::endl;

int main()
  {
  int min = 0.0;
  int max = 4.0;
  float h = 0.01;
  int n = int(max-min)/h;
  double t[n] = { };
  double y[n] = { };
  t[0] = min;
  y[0] = 1.0;
  int i;
  for(i=0; i<n; i++) 
    {
    t[i+1] = t[i]+h;
    y[i+1] = y[i]*(h+1);
    cout<<y[i]<<endl;
    }
  return 0;
  }
